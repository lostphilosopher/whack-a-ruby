# whack-a-ruby

Basic "whack a mole" esque game based on [Learn Game Programming with Ruby](https://pragprog.com/book/msgpkids/learn-game-programming-with-ruby) pgs. 15 - 36.

![Image showing a screen shot of the game.](/demo_screenshot.png "Demo Screenshot")
